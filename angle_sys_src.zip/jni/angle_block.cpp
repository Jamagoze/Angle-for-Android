// angle_block: Zygisk module for angle_sys.
// Apps listed in block.txt (in the module folder) lose only the ANGLE library
// mounts, inside their own mount namespace. They then load the native GPU
// driver. Other modules, root and Zygisk modules are not touched.
#include <fcntl.h>
#include <jni.h>
#include <sched.h>
#include <stdio.h>
#include <string.h>
#include <sys/mount.h>
#include <unistd.h>

#include <string>
#include <vector>

#include "zygisk.hpp"

using zygisk::Api;
using zygisk::AppSpecializeArgs;

namespace {

bool is_blocked(int module_dir, const char *process) {
    // "com.pkg:service" -> "com.pkg"
    std::string pkg(process);
    size_t colon = pkg.find(':');
    if (colon != std::string::npos) pkg.resize(colon);
    if (pkg.empty() || module_dir < 0) return false;

    int fd = openat(module_dir, "block.txt", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return false;
    char buf[16384];
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return false;
    buf[n] = 0;

    char *save = nullptr;
    for (char *line = strtok_r(buf, "\n", &save); line; line = strtok_r(nullptr, "\n", &save)) {
        char *hash = strchr(line, '#');
        if (hash) *hash = 0;
        char *s = line;
        while (*s == ' ' || *s == '\t' || *s == '\r') s++;
        char *e = s + strlen(s);
        while (e > s && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '\r')) *--e = 0;
        if (*s && pkg == s) return true;
    }
    return false;
}

void hide_angle() {
    // Own private mount namespace, so nothing outside this app is affected.
    if (unshare(CLONE_NEWNS) != 0) return;
    mount(nullptr, "/", nullptr, MS_REC | MS_PRIVATE, nullptr);

    static const char *const prefixes[] = {
        "/vendor/lib64/egl", "/vendor/lib/egl",
        "/system/vendor/lib64/egl", "/system/vendor/lib/egl",
    };

    std::vector<std::string> points;
    FILE *f = fopen("/proc/self/mountinfo", "re");
    if (!f) return;
    char line[4096];
    while (fgets(line, sizeof(line), f)) {
        char mp[2048];
        if (sscanf(line, "%*s %*s %*s %*s %2047s", mp) != 1) continue;
        for (const char *p : prefixes) {
            size_t len = strlen(p);
            if (strncmp(mp, p, len) == 0 && (mp[len] == 0 || mp[len] == '/')) {
                points.push_back(mp);
                break;
            }
        }
    }
    fclose(f);

    // Newest mounts first, so mounts on top are removed before their parents.
    for (auto it = points.rbegin(); it != points.rend(); ++it) {
        umount2(it->c_str(), MNT_DETACH);
    }
}

}  // namespace

class AngleBlock : public zygisk::ModuleBase {
public:
    void onLoad(Api *api, JNIEnv *env) override {
        api_ = api;
        env_ = env;
    }

    void preAppSpecialize(AppSpecializeArgs *args) override {
        if (args->nice_name) {
            const char *name = env_->GetStringUTFChars(args->nice_name, nullptr);
            if (name) {
                bool blocked = is_blocked(api_->getModuleDir(), name);
                env_->ReleaseStringUTFChars(args->nice_name, name);
                if (blocked) hide_angle();
            }
        }
        api_->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);
    }

private:
    Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
};

REGISTER_ZYGISK_MODULE(AngleBlock)
