LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := angle_block
LOCAL_SRC_FILES := angle_block.cpp
LOCAL_LDLIBS := -llog
LOCAL_CPPFLAGS := -std=c++17
include $(BUILD_SHARED_LIBRARY)
