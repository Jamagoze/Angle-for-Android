set_perm_recursive $MODPATH/system/vendor/lib64/egl 0 0 0755 0644 u:object_r:same_process_hal_file:s0
[ -d $MODPATH/system/vendor/lib/egl ] && set_perm_recursive $MODPATH/system/vendor/lib/egl 0 0 0755 0644 u:object_r:same_process_hal_file:s0
for s in post-fs-data.sh service.sh uninstall.sh; do
  set_perm $MODPATH/$s 0 0 0755
done

# Keep your block list across updates (also picks up the older list location).
OLD=/data/adb/modules/angle_sys/block.txt
OLDER=/data/adb/angle_sys/block.txt
if [ -f $OLD ]; then
  cp -f $OLD $MODPATH/block.txt
elif [ -f $OLDER ]; then
  cp -f $OLDER $MODPATH/block.txt
fi
# Remove DenyList entries added by the earlier DenyList-based block list.
if [ -f /data/adb/angle_sys/block.applied ]; then
  for p in $(cat /data/adb/angle_sys/block.applied); do magisk --denylist rm "$p" >/dev/null 2>&1; done
  rm -f /data/adb/angle_sys/block.applied /data/adb/angle_sys/block.txt
fi

ui_print "- Bootloop guard: disables itself after 1 failed boot"
ui_print "- Apps that must not use ANGLE: /data/adb/modules/angle_sys/block.txt"
