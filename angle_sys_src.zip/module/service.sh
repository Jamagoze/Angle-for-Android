#!/system/bin/sh
MODDIR=${0%/*}
D=/data/adb/angle_sys

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done

# Boot reached the UI: reset the bootloop counter after 30s of stability.
( sleep 30; echo 0 > "$D/bootcount" ) &

sleep 5
[ -f "$MODDIR/disable" ] && exit 0

# Only enable ANGLE if every library is really visible in /vendor.
for f in libEGL_angle.so libGLESv2_angle.so libGLESv1_CM_angle.so libfeature_support_angle.so; do
  if [ ! -s "/vendor/lib64/egl/$f" ]; then
    resetprop -p --delete persist.graphics.egl
    exit 0
  fi
  if [ -n "$(getprop ro.product.cpu.abilist32)" ] && [ ! -s "/vendor/lib/egl/$f" ]; then
    resetprop -p --delete persist.graphics.egl
    exit 0
  fi
done

resetprop persist.graphics.egl angle
