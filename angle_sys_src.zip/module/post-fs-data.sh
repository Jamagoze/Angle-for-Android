#!/system/bin/sh
# Bootloop guard: service.sh resets the counter once boot is stable.
# If the previous boot never got there, disable the module.
MODDIR=${0%/*}
D=/data/adb/angle_sys
mkdir -p "$D"
C=$(cat "$D/bootcount" 2>/dev/null)
C=$(( ${C:-0} + 1 ))
echo "$C" > "$D/bootcount"
if [ "$C" -ge 2 ]; then
  touch "$MODDIR/disable"
  resetprop -p --delete persist.graphics.egl
  echo 0 > "$D/bootcount"
fi
