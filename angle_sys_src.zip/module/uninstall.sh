#!/system/bin/sh
resetprop -p --delete persist.graphics.egl
rm -rf /data/adb/angle_sys
